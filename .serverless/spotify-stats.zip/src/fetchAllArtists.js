"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetch = void 0;
const axios_1 = __importDefault(require("axios"));
const dotenv_1 = require("dotenv");
const s3_1 = require("./utils/aws/s3");
const secretsManager_1 = require("./utils/aws/secretsManager");
(0, dotenv_1.config)({ path: '.env' });
const spotifyBase = 'https://api.spotify.com/v1';
const BATCH_LIMIT = 100000;
const alphabetLetters = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
    'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
    'y', 'z'
];
/**
 * Fetch a new token for the Spotify API
 * @returns auth token
 */
const authorize = () => __awaiter(void 0, void 0, void 0, function* () {
    const paramStr = 'grant_type=client_credentials';
    const authToken = yield (0, secretsManager_1.getSecret)('spotify_auth_token');
    const response = yield axios_1.default.request({
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${authToken}`
        },
        url: 'https://accounts.spotify.com/api/token',
        data: paramStr
    });
    return response.data.access_token;
});
/**
 * Fetch all artists.
 * {@link https://developer.spotify.com/documentation/web-api/reference/search}
 */
const fetch = () => __awaiter(void 0, void 0, void 0, function* () {
    const token = yield authorize();
    let batchCount = 0;
    let next;
    const date = new Date().toISOString();
    const dir = `data/${date}`;
    try {
        const artistMap = new Map();
        for (const letter of alphabetLetters) {
            next = undefined;
            let artistCountByLetter = 0;
            console.log(`Fetching artists starting with letter "${letter}"`);
            // fetch all artists for the letter
            while (next !== null) {
                const queryStr = `q=${letter}&type=artist`;
                const url = next || `${spotifyBase}/search?${queryStr}&limit=50`;
                console.log(`Requesting... url=${url}`);
                const response = yield axios_1.default.request({
                    method: 'GET',
                    url: url,
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                if (response.status >= 300) {
                    throw new Error(`Request failed. Response: ${JSON.stringify(response.data)}. Request: ${JSON.stringify(response.request)}`);
                }
                artistCountByLetter += response.data.artists.items.length;
                response.data.artists.items.forEach((i) => {
                    artistMap.set(i.id, {
                        id: i.id,
                        name: i.name,
                        popularity: i.popularity
                    });
                });
                next = response.data.artists.next;
            }
            console.log(`Fetched ${artistCountByLetter} artists for letter "${letter}"`);
        }
        console.log(`Fetched ${artistMap.size} artists`);
        const artistsForFile = [];
        artistMap.forEach((value, key) => { artistsForFile.push(value); });
        batchCount += 1;
        yield (0, s3_1.putObject)(artistsForFile, `${dir}/artists-${batchCount}.json`);
    }
    catch (error) {
        console.error(error);
    }
    return date;
});
exports.fetch = fetch;
