"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const fetchAllArtists_1 = require("./fetchAllArtists");
const rankArtists_1 = require("./rankArtists");
const emails_1 = require("./utils/sendgrid/emails");
const emailBody = `
  Here is your weekly report of the current artist rankings. Sourced from Spotify.
`;
const handler = () => __awaiter(void 0, void 0, void 0, function* () {
    const date = yield (0, fetchAllArtists_1.fetch)();
    // const date = '2024-01-06T18:21:00.840Z';
    const rankedArtistsCsvStr = yield (0, rankArtists_1.rank)(date);
    return yield (0, emails_1.sendBatch)(['bshelor24@gmail.com'], `Spotify Rankings - Week of ${new Date().toLocaleDateString()}`, emailBody, emailBody, [
        {
            content: Buffer.from(rankedArtistsCsvStr).toString('base64'),
            filename: `ranked-artists-${new Date().toLocaleDateString()}.csv`,
            type: 'text/csv',
            disposition: 'attachment',
            content_id: 'mytext'
        }
    ]);
});
exports.handler = handler;
// handler()
//   .then(res => {
//     console.log(res);
//     process.exit(0);
//   }).catch(err => {
//     console.log(err);
//     process.exit(1);
//   });
