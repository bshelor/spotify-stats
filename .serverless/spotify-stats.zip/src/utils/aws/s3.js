"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listObjects = exports.deleteObject = exports.getObject = exports.putObject = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3 = new client_s3_1.S3Client({ region: 'us-east-1' });
const Bucket = process.env['BUCKET'];
function putObject(data, keyName) {
    return __awaiter(this, void 0, void 0, function* () {
        const command = new client_s3_1.PutObjectCommand({
            Bucket,
            Key: keyName,
            Body: typeof data === 'string' ? data : JSON.stringify(data)
        });
        return yield s3.send(command);
    });
}
exports.putObject = putObject;
function getObject(path) {
    return __awaiter(this, void 0, void 0, function* () {
        const command = new client_s3_1.GetObjectCommand({
            Bucket,
            Key: path
        });
        const response = yield s3.send(command);
        if (!response.Body) {
            throw new Error(`No object found at ${path}`);
        }
        return JSON.parse(yield response.Body.transformToString());
    });
}
exports.getObject = getObject;
function deleteObject(path) {
    return __awaiter(this, void 0, void 0, function* () {
        const command = new client_s3_1.DeleteObjectCommand({
            Bucket,
            Key: path
        });
        yield s3.send(command);
    });
}
exports.deleteObject = deleteObject;
function listObjects(pathPrefix, paginationToken, limit = 100) {
    var _a;
    return __awaiter(this, void 0, void 0, function* () {
        const command = new client_s3_1.ListObjectsV2Command({
            Bucket,
            Prefix: pathPrefix,
            MaxKeys: limit,
            ContinuationToken: paginationToken
        });
        const result = yield s3.send(command);
        return {
            objects: ((_a = result.Contents) !== null && _a !== void 0 ? _a : []).map(x => {
                var _a, _b;
                return ({
                    path: (_a = x.Key) !== null && _a !== void 0 ? _a : '',
                    modifiedAt: (_b = x.LastModified) !== null && _b !== void 0 ? _b : new Date(),
                });
            }),
            paginationToken: result.ContinuationToken,
        };
    });
}
exports.listObjects = listObjects;
