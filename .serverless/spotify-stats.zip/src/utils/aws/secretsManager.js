"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSecret = void 0;
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const client = new client_secrets_manager_1.SecretsManagerClient({
    region: "us-east-1",
});
/**
 * Retrieve a secret from AWS Secrets Manager
 * @param secretName
 * @returns specified secret
 * @throws error if occurs, see below for possible exceptions thrown
 * {@link https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html}
 */
function getSecret(secretName) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const response = yield client.send(new client_secrets_manager_1.GetSecretValueCommand({ SecretId: secretName }));
            if (response.SecretString) {
                return JSON.parse(response.SecretString)[secretName];
            }
            return response.SecretString;
        }
        catch (error) {
            throw error;
        }
    });
}
exports.getSecret = getSecret;
