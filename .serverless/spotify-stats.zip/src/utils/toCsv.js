"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toCsv = void 0;
/**
 * Convert JSON object array to csv string
 * @param array
 * @returns csv string
 */
const toCsv = (array) => {
    if (!array.length) {
        return '';
    }
    let csvString = '';
    /* headers */
    let first = true;
    Object.keys(array[0]).forEach(k => {
        if (first) {
            csvString += `${k}`;
            first = false;
        }
        else {
            csvString += `,${k}`;
        }
    });
    csvString += '\n';
    array.forEach(e => {
        let first = true;
        Object.keys(e).forEach(k => {
            if (first) {
                csvString += `${e[k]}`;
                first = false;
            }
            else {
                csvString += `,${e[k]}`;
            }
        });
        csvString += '\n';
    });
    return csvString;
};
exports.toCsv = toCsv;
